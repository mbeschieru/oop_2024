//
// Created by Marius Beschieru on 15.03.2024.
//

#include "Adunare.h"

Adunare::Adunare() {
    setName("Adunare");
}

double Adunare::getResult(double x, double y) {
    return x + y;
}
