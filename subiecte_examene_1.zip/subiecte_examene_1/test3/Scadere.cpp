//
// Created by Marius Beschieru on 15.03.2024.
//

#include "Scadere.h"

Scadere::Scadere() {
    setName("Scadere");
}

double Scadere::getResult(double x, double y) {
    return x - y;
}