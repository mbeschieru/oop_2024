//
// Created by Marius Beschieru on 15.03.2024.
//

#include "Impartire.h"

Impartire::Impartire() {
    setName("Impartire");
}

double Impartire::getResult(double x, double y) {
    return x / y;
}