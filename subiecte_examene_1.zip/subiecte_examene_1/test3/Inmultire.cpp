//
// Created by Marius Beschieru on 15.03.2024.
//

#include "Inmultire.h"

Inmultire::Inmultire() {
    setName("Inmultire");
}

double Inmultire::getResult(double x, double y) {
    return x * y;
}